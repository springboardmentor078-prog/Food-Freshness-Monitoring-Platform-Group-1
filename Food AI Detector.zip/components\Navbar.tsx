"use client";

import { useTheme } from "next-themes";
import Link from "next/link";
import { Leaf, Bell, Moon, Sun, ChevronDown, LogOut, Settings, UserCircle, LayoutDashboard, Camera, History, Menu, Package, LineChart, BellRing } from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { useRouter } from "next/navigation";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuGroup,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export function Navbar() {
  const { setTheme, theme } = useTheme();
  const router = useRouter();
  const [userName, setUserName] = useState("User");
  const [userInitials, setUserInitials] = useState("U");

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        try {
          const userDoc = await getDoc(doc(db, "users", user.uid));
          if (userDoc.exists() && userDoc.data().fullname) {
            const fullName = userDoc.data().fullname;
            setUserName(fullName);
            setUserInitials(fullName.substring(0, 2).toUpperCase());
          } else {
            const fallbackName = user.displayName || user.email?.split("@")[0] || "User";
            setUserName(fallbackName);
            setUserInitials(fallbackName.substring(0, 2).toUpperCase());
          }
        } catch (error) {
          console.error("Error fetching user data:", error);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      window.location.href = "/";
    } catch (error) {
      console.error("Failed to log out", error);
    }
  };

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm transition-all duration-300">
      <div className="px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        
        <div className="flex items-center gap-2">
          {/* Mobile Menu */}
          <div className="md:hidden">
            <Sheet>
              <SheetTrigger className="md:hidden inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors hover:bg-accent hover:text-accent-foreground h-10 w-10">
                <Menu className="h-5 w-5" />
              </SheetTrigger>
              <SheetContent side="left" className="w-[250px] sm:w-[300px]">
                <SheetTitle className="mb-4 text-left">Menu</SheetTitle>
                <div className="flex flex-col gap-2 mt-4">
                  <Link href="/dashboard" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-muted text-muted-foreground hover:text-foreground">
                    <LayoutDashboard className="h-5 w-5" /> Dashboard
                  </Link>
                  <Link href="/upload" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-muted text-muted-foreground hover:text-foreground">
                    <Camera className="h-5 w-5" /> New Scan
                  </Link>
                  <Link href="/inventory" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-muted text-muted-foreground hover:text-foreground">
                    <Package className="h-5 w-5" /> My Inventory
                  </Link>
                  <Link href="/history" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-muted text-muted-foreground hover:text-foreground">
                    <History className="h-5 w-5" /> History
                  </Link>
                  <Link href="/insights" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-muted text-muted-foreground hover:text-foreground">
                    <LineChart className="h-5 w-5" /> Insights
                  </Link>
                  <Link href="/alerts" className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium hover:bg-muted text-muted-foreground hover:text-foreground">
                    <BellRing className="h-5 w-5" /> Alerts
                  </Link>
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Logo only visible on mobile when sidebar is hidden */}
          <Link href="/" className="md:hidden flex items-center gap-2 group transition-transform hover:scale-105 active:scale-95">
            <div className="bg-primary/10 p-1.5 rounded-lg group-hover:bg-primary transition-colors">
              <Leaf className="h-5 w-5 text-primary group-hover:text-primary-foreground transition-colors" />
            </div>
            <span className="font-bold text-xl tracking-tight hidden sm:inline-block">FreshTrack</span>
          </Link>
        </div>

        {/* Right side controls */}
        <div className="flex items-center gap-2 sm:gap-4 ml-auto">
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            <Sun className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>
          
          <Button variant="ghost" size="icon" className="rounded-full relative hidden sm:flex">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-warning border-2 border-background"></span>
            <span className="sr-only">Notifications</span>
          </Button>

          {userName !== "User" || userInitials !== "U" ? (
            <DropdownMenu>
              <DropdownMenuTrigger className={buttonVariants({ variant: "ghost", className: "pl-1 pr-2 gap-2 rounded-full hover:bg-muted/50" })}>
                  <Avatar className="h-8 w-8 border border-border">
                    <AvatarImage src="" alt={userName} />
                    <AvatarFallback className="bg-primary/10 text-primary">{userInitials}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium hidden sm:inline-block max-w-[100px] truncate">{userName}</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 rounded-xl">
                <DropdownMenuGroup>
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link href="/profile" className="cursor-pointer w-full flex items-center">
                      <UserCircle className="mr-2 h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Link href="/settings" className="cursor-pointer w-full flex items-center">
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </Link>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-destructive cursor-pointer" onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center gap-2">
              <Link href="/login" className={buttonVariants({ variant: "ghost" })}>
                Log in
              </Link>
              <Link href="/register" className={buttonVariants({ variant: "default", className: "rounded-full" })}>
                Sign up
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
