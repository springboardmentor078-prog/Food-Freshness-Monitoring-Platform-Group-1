"use client";

import { useEffect, useState } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import Image from "next/image";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, CheckCircle2, AlertTriangle, XCircle, Info, CalendarClock, Download } from "lucide-react";
import { FreshnessState } from "@/lib/predictFood";
import { Suspense } from "react";
import jsPDF from "jspdf";
import { SpoiledRegionOverlay } from "@/components/SpoiledRegionOverlay";

function ResultContent() {
  const searchParams = useSearchParams();
  const id = searchParams.get("id");
  const router = useRouter();
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function fetchResult() {
      if (!id) return;
      try {
        const docRef = doc(db, "predictions", id as string);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setResult(docSnap.data());
        } else {
          setError("Result not found.");
        }
      } catch (err) {
        setError("Failed to fetch result.");
      } finally {
        setLoading(false);
      }
    }
    
    fetchResult();
  }, [id]);

  const handleExportPDF = () => {
    if (!result) return;
    const doc = new jsPDF();
    
    doc.setFontSize(22);
    doc.text("FreshTrack Analysis Report", 20, 20);
    
    doc.setFontSize(12);
    doc.text(`Food Item: ${result.food_name}`, 20, 40);
    doc.text(`Freshness Status: ${(result.freshness_category || "unknown").toUpperCase()}`, 20, 50);
    doc.text(`Freshness Score: ${result.score !== null ? result.score + '%' : 'N/A'}`, 20, 60);
    doc.text(`Estimated Shelf Life: ${result.shelf_life}`, 20, 70);
    
    doc.text("Storage Recommendation:", 20, 90);
    const splitRecs = doc.splitTextToSize(result.recommendation, 170);
    doc.text(splitRecs, 20, 100);

    let currentY = 125;
    if (result.spoiled_regions && result.spoiled_regions.length > 0) {
      doc.text("Detected Rippen Regions:", 20, currentY);
      currentY += 10;
      result.spoiled_regions.forEach((region: any, idx: number) => {
        const label = "Rippen area";
        const conf = region.confidence ? ` (${Math.round(region.confidence * 100)}% confidence)` : '';
        doc.text(`- ${label}${conf}`, 25, currentY);
        currentY += 8;
      });
    }
    
    doc.text(`Report ID: ${id}`, 20, 280);
    doc.text(`Date: ${new Date(result.created_at).toLocaleString()}`, 20, 290);
    
    doc.save(`FreshTrack_Report_${result.food_name}.pdf`);
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-4 text-muted-foreground font-medium animate-pulse">Loading analysis...</p>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="text-center mt-20">
        <h2 className="text-2xl font-bold text-destructive mb-4">{error || "Something went wrong"}</h2>
        <Button variant="outline" onClick={() => router.push("/dashboard")}>
          Return to Dashboard
        </Button>
      </div>
    );
  }

  const getStatusConfig = (category: string) => {
    switch (category) {
      case "fresh":
        return {
          icon: <CheckCircle2 className="h-6 w-6 text-primary" />,
          color: "text-primary",
          bg: "bg-primary/10",
          badge: "bg-primary text-primary-foreground hover:bg-primary",
          label: "Fresh & Good"
        };
      case "moderate":
        return {
          icon: <AlertTriangle className="h-6 w-6 text-warning" />,
          color: "text-warning",
          bg: "bg-warning/10",
          badge: "bg-warning text-warning-foreground hover:bg-warning",
          label: "Consume Soon"
        };
      case "spoiled":
        return {
          icon: <XCircle className="h-6 w-6 text-destructive" />,
          color: "text-destructive",
          bg: "bg-destructive/10",
          badge: "bg-destructive text-destructive-foreground hover:bg-destructive",
          label: "Spoiled / Unsafe"
        };
      default:
        return {
          icon: <Info className="h-6 w-6 text-muted-foreground" />,
          color: "text-muted-foreground",
          bg: "bg-muted",
          badge: "bg-muted text-muted-foreground",
          label: "Unknown"
        };
    }
  };

  const config = getStatusConfig(result.freshness_category || "unknown");

  return (
    <div className="max-w-4xl mx-auto">
      <Button 
        variant="ghost" 
        className="mb-6 -ml-4 text-muted-foreground"
        onClick={() => router.push("/upload")}
      >
        <ArrowLeft className="mr-2 h-4 w-4" /> Analyze Another Item
      </Button>

      <div className="grid md:grid-cols-5 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="relative aspect-square w-full rounded-2xl overflow-hidden shadow-xl border border-border bg-card flex items-center justify-center p-1">
            <div className="relative w-full h-full">
              <Image 
                src={result.image_url} 
                alt={result.food_name}
                fill
                className="object-cover"
              />
              <SpoiledRegionOverlay regions={result.spoiled_regions} />
            </div>
            <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6 pt-20 z-20 pointer-events-none">
              <h2 className="text-3xl font-bold text-white capitalize">{result.food_name}</h2>
            </div>
          </div>
          
          <Button variant="outline" className="w-full gap-2" onClick={handleExportPDF}>
            <Download className="h-4 w-4" /> Download PDF Report
          </Button>
        </div>

        <div className="md:col-span-3">
          <Card className="h-full border-border shadow-sm">
            <CardContent className="p-8 flex flex-col h-full">
              
              <div className="flex items-center gap-4 mb-8 pb-8 border-b border-border">
                <div className={`p-4 rounded-2xl ${config.bg}`}>
                  {config.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">Status</h3>
                  <p className={`text-2xl font-bold ${config.color}`}>{config.label}</p>
                </div>
                {result.score !== null && result.score !== undefined && (
                  <div className="text-right">
                    <div className="text-4xl font-extrabold text-foreground tracking-tighter">
                      {result.score}<span className="text-2xl text-muted-foreground">%</span>
                    </div>
                    <p className="text-sm font-medium text-muted-foreground">Freshness Score</p>
                  </div>
                )}
              </div>

              {/* Progress bar / Gauge visualization */}
              {result.score !== null && result.score !== undefined && (
                <div className="mb-8">
                  <div className="h-4 w-full bg-muted rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${result.score >= 80 ? 'bg-primary' : result.score >= 40 ? 'bg-warning' : 'bg-destructive'} transition-all duration-1000 ease-out`}
                      style={{ width: `${result.score}%` }}
                    />
                  </div>
                  <div className="flex justify-between mt-2 text-xs text-muted-foreground font-medium">
                    <span className="flex items-center gap-1">
                      <div className="w-2 h-2 rounded-full bg-destructive" /> Spoiled
                    </span>
                    <span className="flex items-center gap-1">
                      Fresh <div className="w-2 h-2 rounded-full bg-primary" />
                    </span>
                  </div>
                </div>
              )}

              <div className="space-y-8 flex-1">
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <CalendarClock className="h-5 w-5 text-muted-foreground" />
                    <h3 className="text-lg font-semibold">Estimated Shelf Life</h3>
                  </div>
                  <p className="text-foreground text-xl bg-muted/50 inline-block px-4 py-2 rounded-lg border border-border">
                    {result.shelf_life}
                  </p>
                </div>

                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <Info className="h-5 w-5 text-muted-foreground" />
                    <h3 className="text-lg font-semibold">Storage Recommendation</h3>
                  </div>
                  <div className="bg-primary/5 border border-primary/20 rounded-xl p-5">
                    <p className="text-foreground leading-relaxed">
                      {result.recommendation}
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t border-border text-xs text-muted-foreground flex justify-between">
                <span>ID: {id?.slice(0, 8)}...</span>
                <span>{new Date(result.created_at).toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function ResultPage() {
  return (
    <Suspense fallback={<div>Loading...</div>}>
      <ResultContent />
    </Suspense>
  );
}
