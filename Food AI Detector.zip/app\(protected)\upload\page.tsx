"use client";

import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { v4 as uuidv4 } from "uuid";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { doc, setDoc } from "firebase/firestore";
import { auth, db, storage } from "@/lib/firebase";
import { predictFood } from "@/lib/predictFood";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { UploadCloud, X, Loader2, Sparkles } from "lucide-react";

export default function UploadPage() {
  const router = useRouter();
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState("");

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setError("");
    const selected = acceptedFiles[0];
    if (selected) {
      if (selected.size > 5 * 1024 * 1024) {
        setError("File size exceeds 5MB limit.");
        return;
      }
      setFile(selected);
      const objectUrl = URL.createObjectURL(selected);
      setPreview(objectUrl);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "image/jpeg": [],
      "image/png": [],
      "image/jpg": [],
    },
    maxFiles: 1,
  });

  const clearFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setFile(null);
    setPreview(null);
    setError("");
  };

  const handleAnalyze = async () => {
    if (!file || !auth.currentUser) return;
    
    setIsAnalyzing(true);
    setError("");
    
    try {
      const predictionId = uuidv4();
      
      // 1. For DEMO purposes, bypass Firebase Storage to avoid setup errors.
      // We will just use a local blob URL so you can see your uploaded image on the next page.
      const imageUrl = URL.createObjectURL(file);

      // 2. Call predict function
      const result = await predictFood(file);

      // 3. Save to Firestore
      const predictionData = {
        id: predictionId,
        user_id: auth.currentUser.uid,
        image_url: imageUrl,
        food_name: result.food_name,
        freshness_category: result.freshness_category,
        score: result.score,
        fresh_area: result.fresh_area,
        spoiled_area: result.spoiled_area,
        status: result.status,
        shelf_life: result.shelf_life,
        recommendation: result.recommendation,
        spoiled_regions: result.spoiled_regions || [],
        created_at: new Date().toISOString()
      };

      await setDoc(doc(db, "predictions", predictionId), predictionData);

      // 4. Navigate to result page
      router.push(`/result?id=${predictionId}`);

    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to analyze image. Please try again.");
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto mt-8">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold mb-2">Analyze Food Freshness</h1>
        <p className="text-muted-foreground">Upload a photo of your produce to get instant AI-powered freshness insights.</p>
      </div>

      <Card className="border-2 border-dashed shadow-sm overflow-hidden bg-card/50">
        <CardContent className="p-0">
          <AnimatePresence mode="wait">
            {!preview ? (
              <motion.div
                key="dropzone"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
              >
                <div
                  {...getRootProps()}
                  className={`p-16 text-center cursor-pointer transition-colors h-full w-full ${
                    isDragActive ? "bg-primary/5 border-primary" : "hover:bg-muted/50"
                  }`}
                >
                  <input {...getInputProps()} />
                <div className="h-20 w-20 mx-auto rounded-full bg-primary/10 flex items-center justify-center mb-6">
                  <UploadCloud className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Drag & drop your image here</h3>
                <p className="text-muted-foreground mb-4">or click to browse from your device</p>
                <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
                  <span className="bg-muted px-2 py-1 rounded">JPG</span>
                  <span className="bg-muted px-2 py-1 rounded">PNG</span>
                  <span>Max 5MB</span>
                </div>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="preview"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="relative p-6"
              >
                <div className="relative aspect-video w-full max-w-xl mx-auto rounded-xl overflow-hidden shadow-lg border border-border">
                  <Image
                    src={preview}
                    alt="Food preview"
                    fill
                    className="object-cover"
                  />
                  {!isAnalyzing && (
                    <Button
                      variant="destructive"
                      size="icon"
                      className="absolute top-4 right-4 rounded-full h-8 w-8 shadow-md"
                      onClick={clearFile}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                  
                  {isAnalyzing && (
                    <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex flex-col items-center justify-center">
                      <div className="relative w-20 h-20">
                         {/* Scanning animation effect */}
                         <motion.div
                           animate={{
                             top: ["0%", "100%", "0%"],
                           }}
                           transition={{
                             duration: 2,
                             repeat: Infinity,
                             ease: "linear",
                           }}
                           className="absolute left-0 right-0 h-1 bg-primary shadow-[0_0_15px_rgba(34,197,94,0.7)] z-10"
                         />
                         <Loader2 className="h-20 w-20 text-primary/40 animate-spin" />
                      </div>
                      <p className="mt-6 font-medium text-lg animate-pulse flex items-center gap-2">
                        <Sparkles className="h-5 w-5 text-primary" />
                        Analyzing freshness...
                      </p>
                    </div>
                  )}
                </div>

                {!isAnalyzing && (
                  <div className="mt-8 flex justify-center">
                    <Button 
                      size="lg" 
                      onClick={handleAnalyze}
                      className="rounded-xl px-8 h-12 shadow-lg hover:shadow-primary/25 transition-all text-base gap-2"
                    >
                      <Sparkles className="h-5 w-5" />
                      Analyze Freshness
                    </Button>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </CardContent>
      </Card>
      
      {error && (
        <p className="text-center text-destructive font-medium mt-4">{error}</p>
      )}
    </div>
  );
}
