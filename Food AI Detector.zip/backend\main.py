from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.api.routes import predict

app = FastAPI(title="AI Food Freshness API")

# Allow frontend to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(predict.router)

@app.get("/")
def health_check():
    return {"status": "ok", "message": "AI Food Freshness API is running"}
