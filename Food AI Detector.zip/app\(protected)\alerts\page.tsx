"use client";

import { Card, CardContent } from "@/components/ui/card";
import { BellRing, AlertTriangle, Info, ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

const mockAlerts = [
  {
    id: 1,
    type: "critical",
    icon: ShieldAlert,
    title: "Item Expired",
    message: "The Whole Milk in your inventory has expired. Please dispose of it safely.",
    time: "2 hours ago"
  },
  {
    id: 2,
    type: "warning",
    icon: AlertTriangle,
    title: "Consume Soon",
    message: "Your Spinach will expire tomorrow. Consider using it in a recipe today!",
    time: "5 hours ago"
  },
  {
    id: 3,
    type: "info",
    icon: Info,
    title: "Scan Complete",
    message: "Your recent scan for 'Gala Apples' was successful. Added to inventory.",
    time: "2 days ago"
  }
];

export default function AlertsPage() {
  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold tracking-tight mb-2">Alerts & Notifications</h1>
        <p className="text-muted-foreground">Stay on top of your food freshness with timely reminders.</p>
      </div>

      <div className="space-y-4">
        {mockAlerts.map((alert) => (
          <Card key={alert.id} className="border-border shadow-sm overflow-hidden">
            <div className="flex flex-col sm:flex-row">
              <div className={`p-6 flex items-center justify-center sm:w-24 ${
                alert.type === 'critical' ? 'bg-destructive/10 text-destructive' :
                alert.type === 'warning' ? 'bg-warning/10 text-warning' :
                'bg-primary/10 text-primary'
              }`}>
                <alert.icon className="h-8 w-8" />
              </div>
              
              <CardContent className="p-6 flex-1 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <h3 className="text-lg font-semibold">{alert.title}</h3>
                    <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">{alert.time}</span>
                  </div>
                  <p className="text-muted-foreground">{alert.message}</p>
                </div>
                
                <div className="shrink-0 flex sm:flex-col gap-2">
                  <Button variant="outline" size="sm" className="w-full">Dismiss</Button>
                </div>
              </CardContent>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
