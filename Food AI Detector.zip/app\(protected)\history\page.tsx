"use client";

import { useEffect, useState } from "react";
import { collection, query, where, getDocs, orderBy } from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Download, Search, Filter } from "lucide-react";
import jsPDF from "jspdf";
import Link from "next/link";
import Image from "next/image";

export default function HistoryPage() {
  const [predictions, setPredictions] = useState<any[]>([]);
  const [filteredPredictions, setFilteredPredictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Filters
  const [searchTerm, setSearchTerm] = useState("");
  const [filterFreshness, setFilterFreshness] = useState<string>("all");

  useEffect(() => {
    async function fetchHistory() {
      if (!auth.currentUser) return;
      
      try {
        const q = query(
          collection(db, "predictions"),
          where("user_id", "==", auth.currentUser.uid)
        );
        
        const querySnapshot = await getDocs(q);
        const data = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Sort client-side to avoid requiring a Firebase composite index
        data.sort((a: any, b: any) => {
          const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
          const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
          return dateB - dateA;
        });
        
        setPredictions(data);
        setFilteredPredictions(data);
      } catch (err) {
        console.error("Failed to fetch history:", err);
      } finally {
        setLoading(false);
      }
    }
    
    fetchHistory();
  }, []);

  useEffect(() => {
    let result = predictions;
    
    if (searchTerm) {
      result = result.filter(p => p.food_name.toLowerCase().includes(searchTerm.toLowerCase()));
    }
    
    if (filterFreshness !== "all") {
      result = result.filter(p => p.freshness === filterFreshness);
    }
    
    setFilteredPredictions(result);
  }, [searchTerm, filterFreshness, predictions]);

  const exportAllToPDF = () => {
    const doc = new jsPDF();
    
    doc.setFontSize(22);
    doc.text("FreshTrack - Full Scan History", 20, 20);
    
    doc.setFontSize(12);
    let y = 40;
    
    filteredPredictions.forEach((p, index) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(`${index + 1}. ${p.food_name.toUpperCase()} - ${p.freshness} (${p.confidence}%)`, 20, y);
      y += 6;
      doc.setFontSize(10);
      doc.text(`Date: ${new Date(p.created_at).toLocaleDateString()}`, 20, y);
      y += 10;
      doc.setFontSize(12);
    });
    
    doc.save("FreshTrack_History.pdf");
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
        <p className="mt-4 text-muted-foreground font-medium animate-pulse">Loading history...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Scan History</h1>
          <p className="text-muted-foreground">View all your past food freshness analyses.</p>
        </div>
        <Button onClick={exportAllToPDF} variant="outline" className="gap-2 rounded-xl">
          <Download className="h-4 w-4" /> Export Filtered to PDF
        </Button>
      </div>

      <Card className="shadow-sm border-border">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search by food name..." 
                className="pl-9 rounded-xl"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              {['all', 'fresh', 'moderate', 'spoiled'].map((filter) => (
                <Button
                  key={filter}
                  variant={filterFreshness === filter ? "default" : "outline"}
                  className="capitalize rounded-xl"
                  onClick={() => setFilterFreshness(filter)}
                  size="sm"
                >
                  {filter}
                </Button>
              ))}
            </div>
          </div>

          <div className="rounded-xl border overflow-hidden">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow>
                  <TableHead className="w-[100px]">Image</TableHead>
                  <TableHead>Food Item</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Confidence</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPredictions.length > 0 ? (
                  filteredPredictions.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell>
                        <div className="relative h-12 w-12 rounded-lg overflow-hidden border border-border">
                          <Image src={p.image_url} alt={p.food_name} fill className="object-cover" />
                        </div>
                      </TableCell>
                      <TableCell className="font-medium capitalize">{p.food_name}</TableCell>
                      <TableCell>
                        <Badge 
                          variant="outline" 
                          className={
                            p.freshness === "fresh" ? "border-primary text-primary" : 
                            p.freshness === "moderate" ? "border-warning text-warning" : 
                            "border-destructive text-destructive"
                          }
                        >
                          {p.freshness}
                        </Badge>
                      </TableCell>
                      <TableCell>{p.confidence}%</TableCell>
                      <TableCell className="text-muted-foreground text-sm">
                        {new Date(p.created_at).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <Link href={`/result?id=${p.id}`} className={buttonVariants({ variant: "ghost", size: "sm" })}>
                          View Details
                        </Link>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                      No results found matching your filters.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
