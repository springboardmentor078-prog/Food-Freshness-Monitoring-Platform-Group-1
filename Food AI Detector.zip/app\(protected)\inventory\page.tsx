"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Package, Plus } from "lucide-react";
import Link from "next/link";

const mockInventory = [
  { id: 1, name: "Gala Apples", category: "Fruit", added: "2 days ago", status: "Fresh", expires: "in 5 days" },
  { id: 2, name: "Spinach", category: "Vegetable", added: "4 days ago", status: "Consume Soon", expires: "in 1 day" },
  { id: 3, name: "Whole Milk", category: "Dairy", added: "1 week ago", status: "Spoiled", expires: "Expired" },
  { id: 4, name: "Chicken Breast", category: "Meat", added: "Yesterday", status: "Fresh", expires: "in 3 days" },
];

export default function InventoryPage() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight mb-2">My Inventory</h1>
          <p className="text-muted-foreground">Manage the items currently stored in your fridge and pantry.</p>
        </div>
        <Link href="/upload">
          <Button className="gap-2 rounded-xl">
            <Plus className="h-4 w-4" /> Add Item via Scan
          </Button>
        </Link>
      </div>

      <Card className="border-border shadow-sm">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader className="bg-muted/50">
                <TableRow>
                  <TableHead className="w-[50px]"></TableHead>
                  <TableHead>Item Name</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Added</TableHead>
                  <TableHead>Freshness</TableHead>
                  <TableHead className="text-right">Expires</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {mockInventory.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <div className="bg-muted p-2 rounded-md flex items-center justify-center">
                        <Package className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell className="text-muted-foreground">{item.category}</TableCell>
                    <TableCell className="text-muted-foreground">{item.added}</TableCell>
                    <TableCell>
                      <Badge 
                        variant="outline"
                        className={
                          item.status === "Fresh" ? "border-primary text-primary bg-primary/5" :
                          item.status === "Consume Soon" ? "border-warning text-warning bg-warning/5" :
                          "border-destructive text-destructive bg-destructive/5"
                        }
                      >
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-medium">{item.expires}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
