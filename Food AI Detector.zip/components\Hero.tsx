"use client";

import { motion } from "framer-motion";
import { Zap, ArrowRight, CheckCircle2, Clock, UploadCloud } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";
import Link from "next/link";
import Image from "next/image";

export function Hero() {
  return (
    <div className="relative overflow-hidden bg-background py-16 sm:py-24 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          
          {/* Left Column */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="max-w-2xl"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary mb-6 border border-primary/20">
              <Zap className="h-4 w-4" />
              <span className="text-sm font-medium">AI-Powered Freshness Detection</span>
            </div>
            
            <h1 className="text-5xl sm:text-6xl font-extrabold tracking-tight text-foreground mb-6 leading-[1.1]">
              Know Your Food&apos;s <br />
              <span className="text-primary">Freshness</span> Before <br />
              It&apos;s Too Late
            </h1>
            
            <p className="text-lg text-muted-foreground mb-8 max-w-xl leading-relaxed">
              Stop guessing if your produce is still good. Simply snap a photo, and our advanced AI will determine its freshness, predict shelf life, and provide storage tips in seconds.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-12">
              <Link href="/upload" className={buttonVariants({ size: "lg", className: "rounded-xl h-14 px-8 text-base shadow-lg shadow-primary/25 hover:shadow-primary/40 transition-all" })}>
                Upload & Analyze <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
              <Link href="/dashboard" className={buttonVariants({ size: "lg", variant: "outline", className: "rounded-xl h-14 px-8 text-base border-2 hover:bg-muted/50" })}>
                View Dashboard
              </Link>
            </div>
            
            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              <div>
                <p className="text-3xl font-bold text-foreground">50K+</p>
                <p className="text-sm text-muted-foreground mt-1">Images Analyzed</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">98.7%</p>
                <p className="text-sm text-muted-foreground mt-1">Detection Accuracy</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-foreground">&lt;3s</p>
                <p className="text-sm text-muted-foreground mt-1">Avg. Prediction Time</p>
              </div>
            </div>
          </motion.div>

          {/* Right Column */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative lg:ml-auto w-full max-w-lg aspect-square lg:aspect-[4/5] rounded-3xl bg-muted/30 border border-border/50 shadow-2xl p-4 sm:p-8 flex items-center justify-center overflow-hidden"
          >
            {/* Background Blob/Gradient */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-primary/20 blur-3xl rounded-full" />
            
            {/* Main Image Mockup */}
            <div className="relative z-10 w-full h-full bg-card rounded-2xl shadow-xl border border-border flex items-center justify-center overflow-hidden group">
               <img 
                 src="/hero-poster.jpg"
                 alt="AI Food Freshness Detector Mockup"
                 className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
               />
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
}
