import os
import cv2
import base64
import numpy as np
from PIL import Image
from typing import Union, Dict, Any, Optional, List

# Try importing ultralytics YOLO
try:
    from ultralytics import YOLO
    ULTRALYTICS_AVAILABLE = True
except ImportError:
    ULTRALYTICS_AVAILABLE = False
    YOLO = None

# Import configuration settings
try:
    from backend.config import (
        get_active_model_path,
        CONF_THRESHOLD,
        HIGHLIGHT_COLOR_BGR,
        HIGHLIGHT_ALPHA,
        HIGHLIGHT_BORDER_THICKNESS,
        SPOILAGE_KEYWORDS
    )
except ImportError:
    # Fallback default values if imported outside backend context
    def get_active_model_path():
        p = "best.pt"
        return p if os.path.exists(p) else "food_freshness/yolov8_seg_model/weights/best.pt"
    CONF_THRESHOLD = 0.4
    HIGHLIGHT_COLOR_BGR = (0, 69, 255)  # Orange-Red
    HIGHLIGHT_ALPHA = 0.45
    HIGHLIGHT_BORDER_THICKNESS = 2
    SPOILAGE_KEYWORDS = ["rotten", "spoiled", "mold", "decay", "defect", "bad", "bruised", "overripe"]


class SpoilDetector:
    """
    Modular YOLOv8 inference engine for detecting spoiled food regions
    and rendering semi-transparent OpenCV overlays.
    """
    def __init__(self, model_path: Optional[str] = None):
        """
        Initializes the detector with a given .pt weights path.
        If model_path is None, loads from configuration default.
        """
        self.model_path = model_path if model_path else get_active_model_path()
        self.model = None
        self.is_loaded = False
        self.load_error = None
        self._load_model()

    def _load_model(self):
        """Loads the YOLO model with basic error handling."""
        if not ULTRALYTICS_AVAILABLE:
            self.load_error = "ultralytics package is not installed."
            return

        if not os.path.exists(self.model_path):
            self.load_error = f"Model weights file not found at path: {self.model_path}"
            return

        try:
            self.model = YOLO(self.model_path)
            self.is_loaded = True
            self.load_error = None
        except Exception as e:
            self.load_error = f"Failed to load YOLO model: {str(e)}"
            self.is_loaded = False

    def reload_model(self, new_model_path: str):
        """Allows swapping model weights dynamically without restarting the application."""
        self.model_path = new_model_path
        self._load_model()

    def _preprocess_input_image(self, image_input: Union[str, np.ndarray, Image.Image, bytes]) -> Optional[np.ndarray]:
        """Converts diverse image inputs into a standard OpenCV BGR uint8 numpy array."""
        try:
            if isinstance(image_input, str):
                if not os.path.exists(image_input):
                    return None
                img = cv2.imread(image_input)
                return img
            elif isinstance(image_input, bytes):
                nparr = np.frombuffer(image_input, np.uint8)
                img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
                return img
            elif isinstance(image_input, Image.Image):
                img = cv2.cvtColor(np.array(image_input), cv2.COLOR_RGB2BGR)
                return img
            elif isinstance(image_input, np.ndarray):
                if len(image_input.shape) == 3 and image_input.shape[2] == 3:
                    return image_input.copy()
                return None
            return None
        except Exception as e:
            print(f"[SpoilDetector] Image preprocessing error: {e}")
            return None

    def detect_spoilage(
        self,
        image_path_or_array: Union[str, np.ndarray, Image.Image, bytes],
        conf_threshold: float = CONF_THRESHOLD,
        output_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Runs inference on the input image using the loaded YOLOv8 model.
        
        Args:
            image_path_or_array: Path to image, numpy array (BGR), PIL Image, or bytes.
            conf_threshold: Confidence score threshold (default 0.4).
            output_path: Optional file path to save the highlighted image output.
            
        Returns:
            Dict containing:
                - status (str): "Success", "no spoilage detected", "missing weights file", or "Error: unreadable image"
                - highlighted_image (np.ndarray or None): BGR image with overlay
                - highlighted_image_b64 (str or None): Base64 data URI string
                - detections (list): Metadata list of detected regions
                - spoilage_count (int): Number of detected spoiled patches
                - has_spoilage (bool): True if spoilage regions detected
                - model_type (str): "segmentation", "detection", or "none"
        """
        # 1. Error Handling: Check model loading
        if not self.is_loaded:
            return {
                "status": "missing weights file",
                "message": self.load_error or f"Weights file '{self.model_path}' not found.",
                "highlighted_image": None,
                "highlighted_image_b64": None,
                "detections": [],
                "spoilage_count": 0,
                "has_spoilage": False,
                "model_type": "none"
            }

        # 2. Error Handling: Preprocess input image
        img = self._preprocess_input_image(image_path_or_array)
        if img is None:
            return {
                "status": "Error: unreadable image",
                "message": "Input image could not be loaded or decoded.",
                "highlighted_image": None,
                "highlighted_image_b64": None,
                "detections": [],
                "spoilage_count": 0,
                "has_spoilage": False,
                "model_type": "none"
            }

        orig_h, orig_w = img.shape[:2]

        # 3. Run YOLOv8 Inference
        try:
            results = self.model(img, conf=conf_threshold, verbose=False)
            result = results[0]
        except Exception as e:
            return {
                "status": "Error",
                "message": f"YOLOv8 inference failure: {str(e)}",
                "highlighted_image": img,
                "highlighted_image_b64": self._to_base64(img),
                "detections": [],
                "spoilage_count": 0,
                "has_spoilage": False,
                "model_type": "unknown"
            }

        detections = []
        model_type = "detection"
        overlay = img.copy()

        has_masks = hasattr(result, "masks") and result.masks is not None and len(result.masks) > 0
        has_boxes = hasattr(result, "boxes") and result.boxes is not None and len(result.boxes) > 0
        has_probs = hasattr(result, "probs") and result.probs is not None

        combined_mask_layer = np.zeros((orig_h, orig_w, 3), dtype=np.uint8)

        # 4. Handle YOLOv8 Classification Model Output (result.probs)
        if has_probs and not has_masks and not has_boxes:
            model_type = "classification"
            top1_id = int(result.probs.top1)
            top1_name = self.model.names.get(top1_id, f"class_{top1_id}").lower()
            conf = float(result.probs.top1conf.item())

            is_spoiled = any(k in top1_name for k in SPOILAGE_KEYWORDS + ["rotten", "spoiled", "mold", "decay", "rot", "bad"])

            if is_spoiled:
                # Use CV spot detector to locate rotten/mold regions on the image
                from backend.services.cv_detector import detect_spoiled_patches_cv
                # Convert BGR image back to bytes for CV patch detector
                _, buffer = cv2.imencode(".jpg", img)
                cv_patches = detect_spoiled_patches_cv(buffer.tobytes())

                for patch in cv_patches:
                    y_min, x_min, y_max, x_max = patch["box_2d"]
                    x1 = int((x_min / 1000.0) * orig_w)
                    y1 = int((y_min / 1000.0) * orig_h)
                    x2 = int((x_max / 1000.0) * orig_w)
                    y2 = int((y_max / 1000.0) * orig_h)

                    # Fill region on combined mask layer
                    cv2.rectangle(combined_mask_layer, (x1, y1), (x2, y2), HIGHLIGHT_COLOR_BGR, -1)
                    cv2.rectangle(img, (x1, y1), (x2, y2), (0, 30, 255), HIGHLIGHT_BORDER_THICKNESS)

                    patch_label = patch.get("label", "rippen area")

                    detections.append({
                        "class_id": top1_id,
                        "class_name": patch_label,
                        "confidence": patch.get("confidence", round(conf, 4)),
                        "box_2d": patch["box_2d"],
                        "bbox": [x1, y1, x2, y2],
                        "has_mask": False
                    })

                mask_boolean = (combined_mask_layer[:, :, 0] > 0) | (combined_mask_layer[:, :, 1] > 0) | (combined_mask_layer[:, :, 2] > 0)
                highlighted_img = img.copy()
                if np.any(mask_boolean):
                    blended = cv2.addWeighted(img, 1.0 - HIGHLIGHT_ALPHA, combined_mask_layer, HIGHLIGHT_ALPHA, 0)
                    highlighted_img[mask_boolean] = blended[mask_boolean]

                return {
                    "status": "Success",
                    "message": f"Classified as {top1_name} ({conf*100:.1f}% confidence).",
                    "highlighted_image": highlighted_img,
                    "highlighted_image_b64": self._to_base64(highlighted_img),
                    "detections": detections,
                    "spoilage_count": len(detections),
                    "has_spoilage": True,
                    "is_classification": True,
                    "predicted_class": top1_name,
                    "confidence": conf,
                    "model_type": model_type,
                    "saved_path": output_path
                }
            else:
                return {
                    "status": "Success",
                    "message": f"Classified as fresh {top1_name} ({conf*100:.1f}% confidence).",
                    "highlighted_image": img,
                    "highlighted_image_b64": self._to_base64(img),
                    "detections": [],
                    "spoilage_count": 0,
                    "has_spoilage": False,
                    "is_classification": True,
                    "predicted_class": top1_name,
                    "confidence": conf,
                    "model_type": model_type,
                    "saved_path": output_path
                }

        # 5. Handle Case: No detections found
        if not has_masks and not has_boxes:
            return {
                "status": "no spoilage detected",
                "message": "No spoilage detected above confidence threshold.",
                "highlighted_image": img,
                "highlighted_image_b64": self._to_base64(img),
                "detections": [],
                "spoilage_count": 0,
                "has_spoilage": False,
                "model_type": "none"
            }

        # Mask combination layer for smooth blending
        combined_mask_layer = np.zeros((orig_h, orig_w, 3), dtype=np.uint8)

        # 5. Extract Segmentation Masks or Detection Boxes
        if has_masks:
            model_type = "segmentation"
            masks_tensor = result.masks.data  # Tensor (N, H, W)
            boxes = result.boxes

            for i in range(len(masks_tensor)):
                class_id = int(boxes.cls[i].item())
                class_name = self.model.names.get(class_id, f"class_{class_id}")
                conf = float(boxes.conf[i].item())

                # Resize mask tensor to original image dimensions if needed
                mask_np = masks_tensor[i].cpu().numpy().astype(np.uint8)
                if mask_np.shape != (orig_h, orig_w):
                    mask_np = cv2.resize(mask_np, (orig_w, orig_h), interpolation=cv2.INTER_NEAREST)

                # Get bounding box in pixel coordinates [x1, y1, x2, y2]
                xyxy = boxes.xyxy[i].cpu().numpy().astype(int).tolist()
                x1, y1, x2, y2 = xyxy

                # Normalized 0–1000 coordinates [y_min, x_min, y_max, x_max] for API compatibility
                y_min = int(round((y1 / orig_h) * 1000))
                x_min = int(round((x1 / orig_w) * 1000))
                y_max = int(round((y2 / orig_h) * 1000))
                x_max = int(round((x2 / orig_w) * 1000))

                # Color mask layer with semi-transparent highlight color
                combined_mask_layer[mask_np > 0] = HIGHLIGHT_COLOR_BGR

                # Draw contour borders for sharp mask definition
                contours, _ = cv2.findContours(mask_np, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
                cv2.drawContours(img, contours, -1, (0, 30, 255), HIGHLIGHT_BORDER_THICKNESS)

                # Add label tag at top of region
                label_text = f"{class_name} {conf*100:.0f}%"
                cv2.putText(
                    img, label_text, (x1, max(y1 - 8, 15)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2, cv2.LINE_AA
                )

                detections.append({
                    "class_id": class_id,
                    "class_name": class_name,
                    "confidence": round(conf, 4),
                    "box_2d": [y_min, x_min, y_max, x_max],
                    "bbox": [x1, y1, x2, y2],
                    "has_mask": True
                })

        elif has_boxes:
            model_type = "detection"
            boxes = result.boxes

            for i in range(len(boxes)):
                class_id = int(boxes.cls[i].item())
                class_name = self.model.names.get(class_id, f"class_{class_id}")
                conf = float(boxes.conf[i].item())

                xyxy = boxes.xyxy[i].cpu().numpy().astype(int).tolist()
                x1, y1, x2, y2 = xyxy

                y_min = int(round((y1 / orig_h) * 1000))
                x_min = int(round((x1 / orig_w) * 1000))
                y_max = int(round((y2 / orig_h) * 1000))
                x_max = int(round((x2 / orig_w) * 1000))

                # Fill rectangle region on mask layer
                cv2.rectangle(combined_mask_layer, (x1, y1), (x2, y2), HIGHLIGHT_COLOR_BGR, -1)

                # Draw bounding box outline on output image
                cv2.rectangle(img, (x1, y1), (x2, y2), (0, 30, 255), HIGHLIGHT_BORDER_THICKNESS)

                # Draw text badge
                label_text = f"{class_name} {conf*100:.0f}%"
                (w_label, h_label), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
                cv2.rectangle(img, (x1, max(0, y1 - h_label - 6)), (x1 + w_label + 6, max(h_label + 6, y1)), (0, 0, 200), -1)
                cv2.putText(img, label_text, (x1 + 3, max(y1 - 4, 14)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)

                detections.append({
                    "class_id": class_id,
                    "class_name": class_name,
                    "confidence": round(conf, 4),
                    "box_2d": [y_min, x_min, y_max, x_max],
                    "bbox": [x1, y1, x2, y2],
                    "has_mask": False
                })

        # 6. Apply cv2.addWeighted to overlay semi-transparent red/orange highlight
        mask_boolean = (combined_mask_layer[:, :, 0] > 0) | (combined_mask_layer[:, :, 1] > 0) | (combined_mask_layer[:, :, 2] > 0)
        highlighted_img = img.copy()

        if np.any(mask_boolean):
            # Blend overlay onto original image for mask regions
            blended = cv2.addWeighted(img, 1.0 - HIGHLIGHT_ALPHA, combined_mask_layer, HIGHLIGHT_ALPHA, 0)
            highlighted_img[mask_boolean] = blended[mask_boolean]

        # 7. Save output if file path specified
        if output_path:
            try:
                os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
                cv2.imwrite(output_path, highlighted_img)
            except Exception as e:
                print(f"[SpoilDetector] Could not save output image to '{output_path}': {e}")

        has_spoilage = len(detections) > 0

        return {
            "status": "Success" if has_spoilage else "no spoilage detected",
            "message": f"Detected {len(detections)} spoiled region(s)." if has_spoilage else "No spoilage detected.",
            "highlighted_image": highlighted_img,
            "highlighted_image_b64": self._to_base64(highlighted_img),
            "detections": detections,
            "spoilage_count": len(detections),
            "has_spoilage": has_spoilage,
            "model_type": model_type,
            "saved_path": output_path
        }

    def _to_base64(self, img_array: np.ndarray) -> str:
        """Helper to convert BGR image array to JPEG base64 data URL string."""
        try:
            _, buffer = cv2.imencode(".jpg", img_array, [cv2.IMWRITE_JPEG_QUALITY, 85])
            b64_str = base64.b64encode(buffer).decode("utf-8")
            return f"data:image/jpeg;base64,{b64_str}"
        except Exception:
            return ""


# Singleton Instance
_spoil_detector_instance = None

def get_spoil_detector(model_path: Optional[str] = None) -> SpoilDetector:
    """Returns or creates a shared SpoilDetector instance."""
    global _spoil_detector_instance
    if _spoil_detector_instance is None or (model_path and _spoil_detector_instance.model_path != model_path):
        _spoil_detector_instance = SpoilDetector(model_path)
    return _spoil_detector_instance


def detect_spoilage(
    image_path_or_array: Union[str, np.ndarray, Image.Image, bytes],
    conf_threshold: float = CONF_THRESHOLD,
    model_path: Optional[str] = None,
    output_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Standalone function to run spoilage detection and red/orange region highlighting.
    
    Example usage:
        from backend.services.spoil_detector import detect_spoilage
        result = detect_spoilage("sample_apple.jpg", conf_threshold=0.4)
        print(result["status"], result["spoilage_count"])
    """
    detector = get_spoil_detector(model_path)
    return detector.detect_spoilage(image_path_or_array, conf_threshold=conf_threshold, output_path=output_path)
