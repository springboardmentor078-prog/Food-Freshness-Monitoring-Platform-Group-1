export type FreshnessCategory = "fresh" | "moderate" | "spoiled" | "unknown";
export type FreshnessState = FreshnessCategory;

export interface SpoiledRegion {
  box_2d: [number, number, number, number]; // [y_min, x_min, y_max, x_max] normalized 0–1000
  label: string;
  confidence: number;
}

export interface PredictionResult {
  status: string;
  score: number | null;
  fresh_area: number;
  spoiled_area: number;
  food_name: string;
  freshness_category: FreshnessCategory;
  shelf_life: string;
  recommendation: string;
  spoiled_regions?: SpoiledRegion[];
}

export async function predictFood(imageFile: File, foodName?: string): Promise<PredictionResult> {
  // Send image to FastAPI backend
  const formData = new FormData();
  formData.append("file", imageFile);
  if (foodName) {
    formData.append("food_name", foodName);
  }

  const apiUrl = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";
  try {
    const response = await fetch(`${apiUrl}/predict`, {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      const errDetail = await response.text().catch(() => "");
      throw new Error(`Server returned error ${response.status}: ${errDetail || "ML model processing failed"}`);
    }

    const data = await response.json();

    return {
      status: data.status || "Unknown status",
      score: data.score !== null && data.score !== undefined ? Number(data.score.toFixed(1)) : null,
      fresh_area: data.fresh_area || 0,
      spoiled_area: data.spoiled_area || 0,
      food_name: data.food_name || "Unknown",
      freshness_category: data.freshness_category || "unknown",
      shelf_life: data.shelf_life || "Unknown",
      recommendation: data.recommendation || "Monitor closely.",
      spoiled_regions: data.spoiled_regions || [],
    };
  } catch (err: any) {
    if (err.name === "TypeError" || err.message?.includes("fetch")) {
      throw new Error("Backend server is not running on http://localhost:8000. Please start the backend server in terminal.");
    }
    throw err;
  }
}
