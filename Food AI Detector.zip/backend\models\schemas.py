from pydantic import BaseModel
from typing import Optional, List, Dict, Any

class SpoiledRegion(BaseModel):
    box_2d: List[int]  # [y_min, x_min, y_max, x_max] normalized 0–1000
    label: str
    confidence: float

class PredictionResponse(BaseModel):
    status: str
    score: Optional[float] = None
    fresh_area: Optional[float] = 0.0
    spoiled_area: Optional[float] = 0.0
    food_name: str
    freshness_category: str
    shelf_life: str
    recommendation: str
    spoiled_regions: Optional[List[SpoiledRegion]] = []
    highlighted_image_b64: Optional[str] = None
    detection_source: Optional[str] = "yolov8"

class SpoilageHighlightResponse(BaseModel):
    status: str
    message: str
    has_spoilage: bool
    spoilage_count: int
    model_type: str
    detections: List[Dict[str, Any]]
    highlighted_image_b64: Optional[str] = None
