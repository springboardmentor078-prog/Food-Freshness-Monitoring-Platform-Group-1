import json
import os

class RulesService:
    def __init__(self, rules_file_path: str = None):
        if not rules_file_path:
            project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
            rules_file_path = os.path.join(project_root, "data", "shelfLifeRules.json")
            
        self.rules_file_path = rules_file_path
        self.rules = []
        self.default_rule = {}
        self._load_rules()

    def _load_rules(self):
        try:
            with open(self.rules_file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.rules = data.get("rules", [])
                self.default_rule = data.get("default", {})
        except Exception as e:
            print(f"Error loading rules from {self.rules_file_path}: {e}")

    def get_shelf_life_info(self, food_name: str, freshness: str):
        freshness_lower = freshness.lower()
        food_name_lower = food_name.lower()
        
        for rule in self.rules:
            if rule.get("food_name", "").lower() == food_name_lower and \
               rule.get("freshness", "").lower() == freshness_lower:
                return {
                    "shelf_life": rule.get("shelf_life", "Unknown"),
                    "recommendation": rule.get("recommendation", "No recommendation.")
                }
                
        # Smart fallbacks by freshness status if specific fruit is missing
        if freshness_lower == "spoiled":
            return {
                "shelf_life": "0 days",
                "recommendation": "Do not consume. Discard or compost immediately."
            }
        elif freshness_lower == "moderate":
            return {
                "shelf_life": "1-3 days",
                "recommendation": "Consume soon or use in cooking/smoothies."
            }
        elif freshness_lower == "fresh":
            return {
                "shelf_life": "5-7 days",
                "recommendation": "Store in a cool place or refrigerator to prolong shelf life."
            }
            
        return {
            "shelf_life": self.default_rule.get("shelf_life", "Unknown"),
            "recommendation": self.default_rule.get("recommendation", "Monitor closely.")
        }

rules_service = RulesService()
