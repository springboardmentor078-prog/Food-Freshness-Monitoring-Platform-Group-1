"use client";

import React from "react";
import { SpoiledRegion } from "@/lib/predictFood";

interface SpoiledRegionOverlayProps {
  regions?: SpoiledRegion[];
}

export function SpoiledRegionOverlay({ regions }: SpoiledRegionOverlayProps) {
  if (!regions || regions.length === 0) {
    return null;
  }

  return (
    <div className="absolute inset-0 pointer-events-none z-30">
      {regions.map((region, index) => {
        const [yMin, xMin, yMax, xMax] = region.box_2d;

        // Convert normalized 0–1000 coordinates to percentages
        const topY = yMin / 10;
        const bottomY = yMax / 10;
        const leftX = xMin / 10;
        const rightX = xMax / 10;

        const boxWidth = Math.max(rightX - leftX, 5);
        const boxHeight = Math.max(bottomY - topY, 5);

        // Calculate center and diameter for an accurate circle
        const centerX = leftX + boxWidth / 2;
        const centerY = topY + boxHeight / 2;
        const diameter = Math.max(boxWidth, boxHeight) * 1.05;

        const circleTop = Math.max(0, centerY - diameter / 2);
        const circleLeft = Math.max(0, centerX - diameter / 2);
        const size = Math.min(diameter, 100 - Math.max(circleTop, circleLeft));

        const confidencePercent = Math.round((region.confidence ?? 0.95) * 100);
        const labelText = `Rippen Area ${confidencePercent}%`;

        return (
          <div
            key={index}
            className="absolute border-2 border-red-500 bg-red-500/20 rounded-full flex flex-col justify-start items-center transition-all duration-300 shadow-[0_0_18px_rgba(239,68,68,0.7)] animate-pulse"
            style={{
              top: `${circleTop}%`,
              left: `${circleLeft}%`,
              height: `${size}%`,
              width: `${size}%`,
            }}
          >
            <span className="bg-red-600 text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-lg uppercase tracking-wider whitespace-nowrap -mt-3.5 border border-white/40 z-20">
              {labelText}
            </span>
          </div>
        );
      })}
    </div>
  );
}
