from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from typing import Optional
from backend.models.schemas import PredictionResponse, SpoilageHighlightResponse
from backend.services.inference import inference_service
from backend.services.spoil_detector import detect_spoilage
from backend.services.rules import rules_service

router = APIRouter()

@router.post("/predict", response_model=PredictionResponse)
async def predict_image(
    file: UploadFile = File(...),
    food_name: Optional[str] = Form(None),
    mode: Optional[str] = Form("fallback")
):
    try:
        image_bytes = await file.read()
        score_results = inference_service.predict(image_bytes, mode=mode)
        
        status = score_results.get("status", "Error")
        score = score_results.get("score")
        fresh_area = score_results.get("fresh_area", 0.0)
        spoiled_area = score_results.get("spoiled_area", 0.0)
        detected_food = score_results.get("detected_food", "Unknown")
        
        # If food_name isn't provided, use detected_food from model
        final_food_name = food_name if (food_name and food_name != "Unknown") else detected_food
        
        # Determine freshness category based on score
        if score is None:
            freshness_category = "unknown"
        elif score >= 80:
            freshness_category = "fresh"
        elif score >= 40:
            freshness_category = "moderate"
        else:
            freshness_category = "spoiled"
            
        rule_info = rules_service.get_shelf_life_info(final_food_name, freshness_category)
        
        spoiled_regions = score_results.get("spoiled_regions", [])
        highlighted_image_b64 = score_results.get("highlighted_image_b64")
        detection_source = score_results.get("detection_source", "yolov8")
        
        return PredictionResponse(
            status=status,
            score=score,
            fresh_area=fresh_area,
            spoiled_area=spoiled_area,
            food_name=final_food_name,
            freshness_category=freshness_category,
            shelf_life=rule_info["shelf_life"],
            recommendation=rule_info["recommendation"],
            spoiled_regions=spoiled_regions,
            highlighted_image_b64=highlighted_image_b64,
            detection_source=detection_source
        )
    except ValueError as ve:
        raise HTTPException(status_code=500, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")


@router.post("/detect-spoilage", response_model=SpoilageHighlightResponse)
async def detect_spoilage_endpoint(
    file: UploadFile = File(...),
    conf_threshold: float = Form(0.4)
):
    """
    Dedicated endpoint to run YOLOv8 spoiled region detection and return
    highlighted red/orange semi-transparent image along with region metadata.
    """
    try:
        image_bytes = await file.read()
        result = detect_spoilage(image_bytes, conf_threshold=conf_threshold)
        
        return SpoilageHighlightResponse(
            status=result["status"],
            message=result["message"],
            has_spoilage=result["has_spoilage"],
            spoilage_count=result["spoilage_count"],
            model_type=result["model_type"],
            detections=result["detections"],
            highlighted_image_b64=result.get("highlighted_image_b64")
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Spoilage detection failed: {str(e)}")
