import os
import io
import tempfile
import json
import base64
import urllib.request
from PIL import Image
from typing import Optional, Dict, Any

# Add project root to sys.path
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
import sys
if project_root not in sys.path:
    sys.path.append(project_root)

# Import spoil detector service
from backend.services.spoil_detector import get_spoil_detector, detect_spoilage
from backend.services.cv_detector import detect_spoiled_patches_cv
from backend.config import get_active_model_path

try:
    from scoring import FreshnessCalculator
except ImportError:
    FreshnessCalculator = None


def analyze_with_gemini(image_bytes: bytes, api_key: str):
    """
    Calls Gemini API to analyze food freshness and return normalized spoiled regions.
    """
    try:
        encoded_image = base64.b64encode(image_bytes).decode('utf-8')
        url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
        
        prompt_text = """
Analyze this food image for freshness and spoilage.
Return ONLY valid JSON with the following structure:
{
  "detected_food": "name of food",
  "status": "Success",
  "score": 85.0,
  "freshness_category": "fresh",
  "shelf_life": "3-5 days in fridge",
  "recommendation": "Keep refrigerated at 4°C.",
  "spoiled_regions": [
    {
      "box_2d": [y_min, x_min, y_max, x_max],
      "label": "mold",
      "confidence": 0.92
    }
  ]
}
Note: box_2d coordinates MUST be normalized integers from 0 to 1000 [y_min, x_min, y_max, x_max].
If no spoilage, rot, mold, or discoloration is detected, return "spoiled_regions": [].
"""

        payload = {
            "contents": [{
                "parts": [
                    {"text": prompt_text},
                    {"inline_data": {"mime_type": "image/jpeg", "data": encoded_image}}
                ]
            }],
            "generationConfig": {
                "response_mime_type": "application/json"
            }
        }
        
        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        with urllib.request.urlopen(req, timeout=12) as response:
            res_data = json.loads(response.read().decode('utf-8'))
            text = res_data['candidates'][0]['content']['parts'][0]['text']
            parsed = json.loads(text)
            
            if "spoiled_regions" not in parsed or not isinstance(parsed["spoiled_regions"], list):
                parsed["spoiled_regions"] = []
                
            return parsed
    except Exception as e:
        print(f"Gemini API call failed or timed out: {e}")
        return None


class InferenceService:
    def __init__(self):
        self.model_path = get_active_model_path()
        self.spoil_detector = get_spoil_detector(self.model_path)
        self.calculator = FreshnessCalculator() if FreshnessCalculator else None
        
        if self.spoil_detector.is_loaded:
            print(f"✅ Loaded YOLOv8 Spoil Detector model from: {self.model_path}")
        else:
            print(f"⚠️ YOLOv8 model not loaded: {self.spoil_detector.load_error}. Using CV fallback.")

    def predict(self, image_bytes: bytes, mode: str = "fallback") -> Dict[str, Any]:
        """
        Runs freshness prediction using a fallback chain or combined mode:
          1. Gemini API (if GEMINI_API_KEY set)
          2. YOLOv8 Spoil Detector (`spoil_detector.py`)
          3. Pixel-mapping computer vision spot detector (`cv_detector.py`)
        """
        # 1. Check Gemini API first if configured
        api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if api_key:
            gemini_result = analyze_with_gemini(image_bytes, api_key)
            if gemini_result:
                gemini_result["detection_source"] = "gemini"
                return gemini_result

        # 2. Run YOLOv8 Spoil Detector
        yolo_result = self.spoil_detector.detect_spoilage(image_bytes)

        spoiled_regions = []
        highlighted_b64 = None
        detection_source = "none"

        # Format YOLOv8 detections for response
        if yolo_result.get("status") == "Success" and yolo_result.get("has_spoilage"):
            for det in yolo_result["detections"]:
                spoiled_regions.append({
                    "box_2d": det["box_2d"],
                    "label": det["class_name"],
                    "confidence": det["confidence"]
                })
            highlighted_b64 = yolo_result.get("highlighted_image_b64")
            detection_source = "yolov8"

        # 3. Handle Classification vs Detection Fallback
        is_classification = yolo_result.get("is_classification", False)
        predicted_class = yolo_result.get("predicted_class", "").lower()
        is_spoiled = yolo_result.get("has_spoilage", False) or any(k in predicted_class for k in ["rotten", "spoiled", "mold", "decay", "rot", "bad"])

        if is_classification and not is_spoiled:
            # YOLO explicitly classified fruit as FRESH -> Do not run CV spot detector on background shadows!
            spoiled_regions = []
            detection_source = "yolov8_classification"
        elif mode == "combined" or not spoiled_regions:
            # Only run CV spot locator if YOLO detected spoilage or is uncertain
            cv_regions = detect_spoiled_patches_cv(image_bytes)
            if mode == "combined":
                spoiled_regions.extend(cv_regions)
                detection_source = "yolov8+cv_combined" if yolo_result.get("has_spoilage") else "cv_fallback"
            elif not spoiled_regions and is_spoiled and cv_regions:
                spoiled_regions = cv_regions
                detection_source = "cv_fallback"

        # 4. Extract food name from model prediction
        predicted_class = yolo_result.get("predicted_class", "").lower()
        detected_food = "Food Item"
        if "apple" in predicted_class:
            detected_food = "Apple"
        elif "banana" in predicted_class:
            detected_food = "Banana"
        elif "orange" in predicted_class:
            detected_food = "Orange"

        # 5. Calculate Freshness Score
        is_classification = yolo_result.get("is_classification", False)
        is_spoiled = yolo_result.get("has_spoilage", False) or any(k in predicted_class for k in ["rotten", "spoiled", "mold", "decay", "rot", "bad"])
        conf = yolo_result.get("confidence", 0.90)

        if is_classification and is_spoiled:
            # Classification model detected rotten/spoiled fruit with high confidence
            score = round(max(2.0, (1.0 - conf) * 100.0), 1)
            freshness_cat = "spoiled"
            status = "Success"
        elif is_classification and not is_spoiled:
            # Classification model detected fresh fruit
            score = round(min(98.0, conf * 100.0), 1)
            freshness_cat = "fresh"
            status = "Success"
        elif len(spoiled_regions) > 0:
            # Object detection or CV found spoiled regions
            total_penalty = sum(r.get("confidence", 0.8) * 35 for r in spoiled_regions)
            score = max(5.0, round(95.0 - total_penalty, 1))
            status = "Success"
            freshness_cat = "spoiled" if score < 40 else "moderate"
        else:
            score = 95.0
            status = "Success"
            freshness_cat = "fresh"

        return {
            "status": status,
            "score": score,
            "fresh_area": round(max(0.0, score), 1),
            "spoiled_area": round(max(0.0, 100.0 - score), 1),
            "detected_food": detected_food,
            "freshness_category": freshness_cat,
            "spoiled_regions": spoiled_regions,
            "highlighted_image_b64": highlighted_b64,
            "detection_source": detection_source,
            "spoil_detector_status": yolo_result.get("status")
        }


inference_service = InferenceService()
