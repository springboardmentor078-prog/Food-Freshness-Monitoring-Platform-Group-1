import os

# Base Directory of the Project
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))

# Configurable YOLOv8 Model Weights Path
# Checks env variable YOLO_MODEL_PATH first, then common fallback locations
DEFAULT_MODEL_PATH = os.getenv(
    "YOLO_MODEL_PATH",
    os.path.join(BASE_DIR, "best.pt")
)

# Alternative model locations if default path does not exist
FALLBACK_MODEL_PATHS = [
    DEFAULT_MODEL_PATH,
    os.path.join(BASE_DIR, "food_freshness", "yolov8_seg_model", "weights", "best.pt"),
    os.path.join(BASE_DIR, "food_freshness", "yolov8_model", "weights", "best.pt"),
    os.path.join(BASE_DIR, "best.onnx")
]

def get_active_model_path() -> str:
    """Returns the first existing model weights path from fallbacks."""
    for path in FALLBACK_MODEL_PATHS:
        if os.path.exists(path):
            return path
    return DEFAULT_MODEL_PATH

# Default Detection Settings
CONF_THRESHOLD = float(os.getenv("CONF_THRESHOLD", "0.4"))

# Highlighting Overlay Config (BGR format for OpenCV)
# (0, 69, 255) is Orange-Red, (0, 0, 255) is Pure Red
HIGHLIGHT_COLOR_BGR = (0, 69, 255)
HIGHLIGHT_ALPHA = 0.45  # Opacity of overlay (0.0 to 1.0)
HIGHLIGHT_BORDER_THICKNESS = 2

# Target spoilage-related class labels (case-insensitive keyword matching)
SPOILAGE_KEYWORDS = ["rotten", "spoiled", "mold", "decay", "defect", "bad", "bruised", "overripe"]
