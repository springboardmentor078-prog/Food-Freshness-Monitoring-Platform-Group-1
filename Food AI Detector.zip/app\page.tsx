import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { Leaf, Camera, ShieldCheck, Clock, ArrowRight, Zap } from "lucide-react";
import Link from "next/link";
import { buttonVariants } from "@/components/ui/button";

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-1">
        <Hero />

        {/* How it Works Section */}
        <section className="py-24 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl font-bold tracking-tight mb-4">How FreshTrack Works</h2>
              <p className="text-muted-foreground text-lg">
                Three simple steps to ensure you never consume spoiled food again.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-12 max-w-5xl mx-auto relative">
              {/* Connecting line for desktop */}
              <div className="hidden md:block absolute top-12 left-[15%] right-[15%] h-0.5 bg-border z-0" />
              
              <div className="relative z-10 flex flex-col items-center text-center">
                <div className="h-24 w-24 rounded-full bg-background border-4 border-primary/20 flex items-center justify-center mb-6 shadow-xl">
                  <Camera className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">1. Snap a Photo</h3>
                <p className="text-muted-foreground">Take a clear picture of your produce or scan an existing image from your gallery.</p>
              </div>

              <div className="relative z-10 flex flex-col items-center text-center">
                <div className="h-24 w-24 rounded-full bg-background border-4 border-primary/20 flex items-center justify-center mb-6 shadow-xl">
                  <ShieldCheck className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">2. AI Analysis</h3>
                <p className="text-muted-foreground">Our computer vision model analyzes texture, color, and visual cues instantly.</p>
              </div>

              <div className="relative z-10 flex flex-col items-center text-center">
                <div className="h-24 w-24 rounded-full bg-background border-4 border-primary/20 flex items-center justify-center mb-6 shadow-xl">
                  <Clock className="h-10 w-10 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-3">3. Get Insights</h3>
                <p className="text-muted-foreground">Receive a freshness score, estimated shelf life, and optimal storage recommendations.</p>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid */}
        <section className="py-24 bg-background">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16">
              <h2 className="text-3xl font-bold tracking-tight mb-4">Why choose FreshTrack?</h2>
              <p className="text-muted-foreground text-lg max-w-2xl">
                Built with cutting-edge AI to help you reduce food waste and save money.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { title: "Reduce Waste", desc: "Save up to $1,500/year by consuming food before it spoils.", icon: Leaf },
                { title: "Instant Results", desc: "Get real-time feedback with >98% accuracy on supported items.", icon: Zap },
                { title: "Smart Storage", desc: "Learn the best ways to store different types of produce.", icon: ShieldCheck },
                { title: "Track History", desc: "Monitor your scanning habits and freshness trends over time.", icon: Clock }
              ].map((feature, i) => (
                <div key={i} className="p-6 rounded-2xl border border-border bg-card shadow-sm hover:shadow-md transition-shadow">
                  <feature.icon className="h-8 w-8 text-primary mb-4" />
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Bottom CTA */}
        <section className="py-24 bg-primary/5 border-t border-border">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to check your food?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
              Join thousands of users who are already reducing food waste with FreshTrack.
            </p>
            <Link href="/upload" className={buttonVariants({ size: "lg", className: "rounded-xl h-14 px-8 text-base" })}>
              Start Analyzing Now <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-8 border-t border-border bg-background">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Leaf className="h-4 w-4 text-primary" />
            <span className="font-semibold text-foreground">FreshTrack</span>
          </div>
          <p>&copy; {new Date().getFullYear()} FreshTrack. All rights reserved. Free Tier Project.</p>
        </div>
      </footer>
    </div>
  );
}
